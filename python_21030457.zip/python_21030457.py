import random


# Check for the winning condition
def end(symbol):
    for x in range(0, 3):
        count_row = 0
        # Check for row
        for y in range(0, 3):
            if my_list[x][y] == symbol:
                count_row += 1
        if count_row == 3:
            return False
        # Check for column
        count_column = 0
        for z in range(0, 3):
            if my_list[z][x] == symbol:
                count_column += 1
        if count_column == 3:
            return False
    # Check for diagonal
    count_diagonal1 = 0
    count_diagonal2 = 0
    for o in range(0, 3):
        if my_list[o][o] == symbol:
            count_diagonal1 += 1
        if my_list[o][-(o + 1)] == symbol:
            count_diagonal2 += 1
    if count_diagonal1 == 3:
        return False
    if count_diagonal2 == 3:
        return False
    return True


# Check for draw condition
def draw():
    count_draw = 0
    for x in range(0, 3):
        for y in range(0, 3):
            if my_list[x][y] == 'X' or my_list[x][y] == 'O':
                count_draw += 1
            if count_draw == 9:
                return False
    return True


# Computer input to block or to win
def win_and_block(symbol):
    global my_log_row
    global my_log_column
    for x in range(0, 3):
        count_row = 0
        count_column = 0
        # Check row for 2 same symbol
        for y in range(0, 3):
            if my_list[x][y] == symbol:
                count_row += 1
        # Computer input
        if count_row == 2:
            for z in range(0, 3):
                if my_list[x][z] == '':
                    my_list[x][z] = 'O'
                    my_log_row.append(x + 1)
                    my_log_column.append(z + 1)
                    return False
        # Check column for 2 same symbol
        for m in range(0, 3):
            if my_list[m][x] == symbol:
                count_column += 1
        # Computer input
        if count_column == 2:
            for n in range(0, 3):
                if my_list[n][x] == '':
                    my_list[n][x] = 'O'
                    my_log_row.append(n + 1)
                    my_log_column.append(x + 1)
                    return False
        # Check top left to bottom right diagonal for 2 same symbol
        count_diagonal1 = 0
        count_diagonal2 = 0
        for o in range(0, 3):
            if my_list[o][o] == symbol:
                count_diagonal1 += 1
        # Computer input
        if count_diagonal1 == 2:
            for m in range(0, 3):
                if my_list[m][m] == '':
                    my_list[m][m] = 'O'
                    my_log_row.append(m + 1)
                    my_log_column.append(m + 1)
                    return False
        # Check top right to bottom left diagonal for 2 same symbol
        for o in range(0, 3):
            if my_list[o][-(o + 1)] == symbol:
                count_diagonal2 += 1
        # Computer input
        if count_diagonal2 == 2:
            for m in range(0, 3):
                if my_list[m][-(m + 1)] == '':
                    my_list[m][-(m + 1)] = 'O'
                    my_log_row.append(m + 1)
                    if m == 0:
                        my_log_column.append(3)
                    elif m == 1:
                        my_log_column.append(2)
                    elif m == 2:
                        my_log_column.append(1)

                    return False
    return True


# Print the log in a text file
def log():
    file = open('C:/Users/mazym/PycharmProjects/pythonProject/CSC1024/log file_21030457.txt', 'w')
    count_log = 0
    steps_log = len(my_log_column)
    for log1 in range(steps_log):
        count_log += 1
        # User start first
        if start_first.upper() == 'Y':
            if log1 % 2 == 0:
                file.write(str(count_log) + ' U ' + str(my_log_row[count_log - 1]) + ' ' +
                           str(my_log_column[count_log - 1]) + ' X ' + '\n')
            if log1 % 2 == 1:
                file.write(str(count_log) + ' C ' + str(my_log_row[count_log - 1]) + ' ' +
                           str(my_log_column[count_log - 1]) + ' O ' + '\n')
        # Computer start first
        else:
            if log1 % 2 == 0:
                file.write(str(count_log) + ' C ' + str(my_log_row[count_log - 1]) + ' ' +
                           str(my_log_column[count_log - 1]) + ' O ' + '\n')
            if log1 % 2 == 1:
                file.write(str(count_log) + ' U ' + str(my_log_row[count_log - 1]) + ' ' +
                           str(my_log_column[count_log - 1]) + ' X ' + '\n')
    file.close()


# Printing the 3 X 3 board
def printing():
    print('-' * 25)
    for x in range(0, 3):
        print('|', end='')
        for y in range(0, 3):
            print('%4s' % my_list[x][y], end='')
            print('%4s' % "|", end='')
        print()
        print('-' * 25)


# Execution of program
continuous = True
play_again = True
while play_again:
    my_list = [['', '', ''],
               ['', '', ''],
               ['', '', '']]
    # my_log_row and my_log_column used to store the move taken by user and computer
    my_log_row = []
    my_log_column = []
    # Printing of board
    printing()
    # Prompt user if they want to go first
    start_first = input('Do you want to start first(Y or N)?:')
    while start_first.upper() != 'Y' and start_first.upper() != 'N':
        start_first = input('Please enter Y or N: ')
    print('You are X')
    # Randomise computer input if user does not want to start first
    if start_first.upper() == 'N':
        ran_num1 = random.randint(0, 2)
        ran_num2 = random.randint(0, 2)
        my_list[ran_num1][ran_num2] = 'O'
        my_log_row.append(ran_num1 + 1)
        my_log_column.append(ran_num2 + 1)
        printing()

    while continuous:
        # Prompt for row and column
        row = int(input("Please enter row(1, 2 or 3):"))
        column = int(input("Please enter column(1, 2 or 3):"))
        # User input and check user input
        if 0 < row < 4 and 0 < column < 4:
            if my_list[row - 1][column - 1] == '':
                if row == 1:
                    my_list[0][column - 1] = 'X'
                elif row == 2:
                    my_list[1][column - 1] = 'X'
                elif row == 3:
                    my_list[2][column - 1] = 'X'
                my_log_row.append(row)
                my_log_column.append(column)
                # Check for user winning and drawing conditions
                if not end('X'):
                    continuous = end('X')
                    printing()
                    print("You WIN!!!")
                    break
                elif not draw():
                    continuous = draw()
                    printing()
                    print("It is a draw")
                    break
                # Computer input to win
                if win_and_block('O'):
                    # Computer input to block
                    if win_and_block('X'):
                        # Computer random input
                        if continuous:
                            checking = True
                            while checking:
                                ran_num1 = random.randint(0, 2)
                                ran_num2 = random.randint(0, 2)
                                if my_list[ran_num1][ran_num2] == '':
                                    my_list[ran_num1][ran_num2] = 'O'
                                    my_log_row.append(ran_num1 + 1)
                                    my_log_column.append(ran_num2 + 1)
                                    break

                printing()
                # Check for computer winning and drawing conditions
                if not end('O'):
                    continuous = end('O')
                    print("You LOSE!")
                    break
                elif not draw():
                    continuous = draw()
                    print("It is a draw")
                    break

            else:
                print('This spot is filled, please choose another spot')
        else:
            print("Please enter a number between 1 and 3")

    log()
    # Prompt user if they want to play again
    play_again = input('Do you want to play again?(Y or N)?:')
    while play_again.upper() != 'Y' and play_again.upper() != 'N':
        play_again = input("Please enter Y or N:")
    if play_again.upper() == 'Y':
        continuous = True
    elif play_again.upper() == 'N':
        play_again = False
    else:
        print('Please enter Y or N:')

print("Thank you for playing")
